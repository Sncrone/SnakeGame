from graphics import Canvas
import random
import time

CANVAS_WIDTH = 300
CANVAS_HEIGHT = 350
PATCH_SIZE = 30
GRID_SIZE = 10
SNAKE_COLOR = "darkgreen"
SCOREBOARD_HEIGHT = 50

def main():
    canvas = Canvas(CANVAS_WIDTH, CANVAS_HEIGHT)
    high_score = 0

    while True:
        current_score = play_game(canvas, high_score)
        
        if current_score > high_score:
            high_score = current_score

        # End of Game Message
        canvas.create_text(CANVAS_WIDTH // 2, CANVAS_HEIGHT // 2 - 20, "Game Over!", "black", 20)
        canvas.create_text(CANVAS_WIDTH // 2, CANVAS_HEIGHT // 2 + 10, "Click to Play Again", "black", 14)
        
        # Wait for Click to Restart
        canvas.wait_for_click()
        canvas.clear()  # Clear the entire canvas for a fresh restart

def play_game(canvas, high_score):
    for row in range(GRID_SIZE):
        draw_grid_row(canvas, 0, row * PATCH_SIZE)
    
    snake = [(2, 5), (2, 4)]
    direction = "RIGHT"

    for x, y in snake:
        draw_square(canvas, x * PATCH_SIZE, y * PATCH_SIZE, SNAKE_COLOR)

    food_pos = place_food(canvas, snake)
    food_x, food_y = food_pos
    draw_square(canvas, food_x * PATCH_SIZE, food_y * PATCH_SIZE, "red")

    current_score = 0

    while True:
        key = canvas.get_last_key_press()

        if key == "ArrowUp" and direction != "DOWN":
            direction = "UP"
        elif key == "ArrowDown" and direction != "UP":
            direction = "DOWN"
        elif key == "ArrowLeft" and direction != "RIGHT":
            direction = "LEFT"
        elif key == "ArrowRight" and direction != "LEFT":
            direction = "RIGHT"

        new_snake = update_snake(snake, direction)
        head_x, head_y = new_snake[0]

        if head_x < 0 or head_x >= GRID_SIZE or head_y < 0 or head_y >= GRID_SIZE:
            print("Game Over! Hit the wall!")
            break

        if (head_x, head_y) in snake[:-1]: 
            print("Game Over! Hit your own tail!")
            break

        ate_food = False
        if (head_x, head_y) == food_pos:
            ate_food = True
            current_score += 1
            food_pos = place_food(canvas, new_snake)
            new_food_x, new_food_y = food_pos
            draw_square(canvas, new_food_x * PATCH_SIZE, new_food_y * PATCH_SIZE, "red")

        # Update scoreboard
        canvas.create_rectangle(0, CANVAS_HEIGHT - SCOREBOARD_HEIGHT, CANVAS_WIDTH, CANVAS_HEIGHT, "white", "white")
        draw_scoreboard(canvas, current_score, high_score)
        
        if ate_food:
            new_snake = [new_snake[0]] + snake
            head_x_draw, head_y_draw = new_snake[0]
            draw_square(canvas, head_x_draw * PATCH_SIZE, head_y_draw * PATCH_SIZE, SNAKE_COLOR)
        else:
            old_tail_x, old_tail_y = snake[-1]
            draw_square(canvas, old_tail_x * PATCH_SIZE, old_tail_y * PATCH_SIZE, "lightgray")
            head_x_draw, head_y_draw = new_snake[0]
            draw_square(canvas, head_x_draw * PATCH_SIZE, head_y_draw * PATCH_SIZE, SNAKE_COLOR)

        snake = new_snake

        time.sleep(0.3)
    
    return current_score

def update_snake(snake, direction):
    head_x, head_y = snake[0]

    if direction == "UP":
        new_head = (head_x, head_y - 1)
    elif direction == "DOWN":
        new_head = (head_x, head_y + 1)
    elif direction == "LEFT":
        new_head = (head_x - 1, head_y)
    elif direction == "RIGHT":
        new_head = (head_x + 1, head_y)

    return [new_head] + snake[:-1]

def place_food(canvas, snake):
    max_attempts = 100
    attempts = 0
    
    while attempts < max_attempts:
        row = random.randint(0, GRID_SIZE - 1)
        col = random.randint(0, GRID_SIZE - 1)
        
        if (col, row) not in snake:
            return (col, row)
        
        attempts += 1
    
    return (random.randint(0, GRID_SIZE - 1), random.randint(0, GRID_SIZE - 1))

def draw_grid_row(canvas, start_x, start_y):
    for col in range(GRID_SIZE): 
        x = start_x + col * PATCH_SIZE
        draw_square(canvas, x, start_y)

def draw_square(canvas, start_x, start_y, color="lightgray"):
    end_x = start_x + PATCH_SIZE
    end_y = start_y + PATCH_SIZE
    canvas.create_rectangle(start_x, start_y, end_x, end_y, color, 'black')

def draw_scoreboard(canvas, current_score, high_score):
    canvas.create_rectangle(0, CANVAS_HEIGHT - SCOREBOARD_HEIGHT, CANVAS_WIDTH, CANVAS_HEIGHT, "white", "white")
    canvas.create_rectangle(10, 335, 25, 320, "red", "red")  # Red square icon
    canvas.create_text(35, 325, f"Score: {current_score}", "black", 12)
    canvas.create_rectangle(160, 335, 175, 320, "gold", "gold")  # Trophy icon
    canvas.create_text(185, 325, f"Best: {high_score}", "black", 12)

if __name__ == '__main__':
    main()